package com.example.consumo_servicos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
